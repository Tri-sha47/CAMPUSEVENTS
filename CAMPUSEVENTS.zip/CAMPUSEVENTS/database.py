import sqlite3

conn = sqlite3.connect('campus.db')
c = conn.cursor()

# College table
c.execute('''
CREATE TABLE IF NOT EXISTS College (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
)
''')

# Event table
c.execute('''
CREATE TABLE IF NOT EXISTS Event (
    id TEXT PRIMARY KEY,
    college_id INTEGER,
    title TEXT,
    description TEXT,
    date TEXT,
    event_type TEXT,
    capacity INTEGER,
    status TEXT DEFAULT 'active',
    FOREIGN KEY (college_id) REFERENCES College(id)
)
''')

# Student table
c.execute('''
CREATE TABLE IF NOT EXISTS Student (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    college_id INTEGER,
    name TEXT,
    email TEXT,
    FOREIGN KEY (college_id) REFERENCES College(id)
)
''')

# Registration table
c.execute('''
CREATE TABLE IF NOT EXISTS Registration (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    event_id TEXT,
    registration_date TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, event_id),
    FOREIGN KEY (student_id) REFERENCES Student(id),
    FOREIGN KEY (event_id) REFERENCES Event(id)
)
''')

# Attendance table
c.execute('''
CREATE TABLE IF NOT EXISTS Attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    event_id TEXT,
    checkin_time TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Student(id),
    FOREIGN KEY (event_id) REFERENCES Event(id)
)
''')

# Feedback table
c.execute('''
CREATE TABLE IF NOT EXISTS Feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    event_id TEXT,
    rating INTEGER,
    comments TEXT,
    submitted_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Student(id),
    FOREIGN KEY (event_id) REFERENCES Event(id)
)
''')

conn.commit()
conn.close()
print("Database setup complete!")