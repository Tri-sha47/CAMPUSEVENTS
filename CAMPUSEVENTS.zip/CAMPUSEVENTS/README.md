![alt text](Capture.JPG)![alt text](Capture1.JPG)![alt text](Capture2.JPG)![alt text](Capture4.JPG)![alt text](Capture5.JPG)![alt text]c:\Users\Ḥ\Pictures\Capture7.JPG(Capture6.JPG)![![alt text](Capture8.JPG)![alt text](Capture12.JPG)![alt text](Capture13.JPG)![alt text](Capture14.JPG)![
    
](Capture15.JPG)
](Capture7.JPG)
**IMAGE 1**
I navigated to my project folder C: \CAMPUSEVENTS in PowerShell, which contains all my project files like mainn.py.

2. I checked that the required Python packages, such as Flask, are already installed. The terminal confirmed this with messages like "Requirement already satisfied."

3. I tried running my main Python file using python mainn. py. This step executed the script, but it didn't display output because the server code was not set to start automatically or print messages.

4. I realized that for my Campus Event Management prototype, I need to use FastAPI and Uvicorn to run the server properly and open the interactive API documentation (/docs).

Overall, these steps helped me ensure that my environment is correctly set up, packages are installed, and the project folder structure is ready for running.
**IMAGE2**
In the window, I am looking at the contents of a folder named CAMPUSEVENTS. The list of files inside the folder includes:

campus.db: A database file.

database.py: A Python file, likely for handling the database.

mainn.py: Another Python file, probably the main program.

README.md: A file with instructions or a description of the project.

test_flask.py: A Python file related to Flask, which is a tool for building websites.

Basically, I am using a text-based tool to see what's in a specific project folder, which looks like it's for a campus events website or application.
**IMAGE 3**
First, I used the command python -m pip install flask. This command installs the Flask web framework for Python. The output shows that all the necessary requirements for Flask are already satisfied, which means it's already installed. The message "Defaulting to user installation because normal site-packages is not writeable" just indicates that I'm installing it to my specific user directory rather than a system-wide one, which is common.

Next, I ran the command python -c "import database; database. setup_database ()". This is a one-line Python script executed directly from the command prompt.

import database: This imports a Python module I've named database.

database. setup_database(): This calls a function named setup_database from the database module
**IMAGE 4**
This is the image showing the pip list
**IMAGE 5 to IMAGE12**
API (Application Programming Interface) testing is a type of software testing that focuses on validating the functionality, reliability, performance, and security of APIs. Unlike UI testing, API testing directly interacts with the application’s backend to ensure that requests and responses work as expected.
I performed API testing by first understanding the endpoints, methods, and parameters. Then I used tools like Postman to send requests (GET, POST, PUT, DELETE) and validated the responses for correctness, status codes, and data format. I also checked performance and security aspects to ensure the API was reliable and secure. Finally, I documented the results and automated some tests for consistency.
