from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="Campus Event Management")

# -----------------------------
# Data Models
# -----------------------------
class College(BaseModel):
    id: int
    name: str

class Student(BaseModel):
    id: int
    name: str
    college_id: int

class Event(BaseModel):
    id: int
    college_id: int
    title: str
    event_type: str
    capacity: int

class Registration(BaseModel):
    id: int
    student_id: int
    event_id: int
    status: str = "registered"
    checked_in: bool = False

class Feedback(BaseModel):
    student_id: int
    event_id: int
    rating: int

# -----------------------------
# In-memory storage
# -----------------------------
colleges: List[College] = []
students: List[Student] = []
events: List[Event] = []
registrations: List[Registration] = []
feedbacks: List[Feedback] = []

# -----------------------------
# College APIs
# -----------------------------
@app.post("/colleges")
def create_college(college: College):
    colleges.append(college)
    return college

@app.get("/colleges")
def list_colleges():
    return colleges

# -----------------------------
# Student APIs
# -----------------------------
@app.post("/students")
def create_student(student: Student):
    if not any(c.id == student.college_id for c in colleges):
        raise HTTPException(status_code=404, detail="College not found")
    students.append(student)
    return student

@app.get("/students")
def list_students():
    return students

# -----------------------------
# Event APIs
# -----------------------------
@app.post("/events")
def create_event(event: Event):
    if not any(c.id == event.college_id for c in colleges):
        raise HTTPException(status_code=404, detail="College not found")
    events.append(event)
    return event

@app.get("/events")
def list_events():
    return events

# -----------------------------
# Registration APIs
# -----------------------------
@app.post("/events/{event_id}/register")
def register_student(event_id: int, student_id: int):
    if not any(e.id == event_id for e in events):
        raise HTTPException(status_code=404, detail="Event not found")
    if not any(s.id == student_id for s in students):
        raise HTTPException(status_code=404, detail="Student not found")
    if any(r.student_id == student_id and r.event_id == event_id for r in registrations):
        raise HTTPException(status_code=400, detail="Already registered")
    reg = Registration(id=len(registrations)+1, student_id=student_id, event_id=event_id)
    registrations.append(reg)
    return {"status": "registered", "registration_id": reg.id}

@app.post("/events/{event_id}/checkin")
def mark_attendance(event_id: int, student_id: int):
    for r in registrations:
        if r.event_id == event_id and r.student_id == student_id:
            r.checked_in = True
            return {"status": "checked_in", "student_id": student_id, "event_id": event_id}
    raise HTTPException(status_code=404, detail="Registration not found")

# -----------------------------
# Feedback APIs
# -----------------------------
@app.post("/events/{event_id}/feedback")
def submit_feedback(event_id: int, student_id: int, rating: int):
    if rating < 1 or rating > 5:
        raise HTTPException(status_code=400, detail="Rating must be 1-5")
    if not any(r.student_id == student_id and r.event_id == event_id for r in registrations):
        raise HTTPException(status_code=404, detail="Student not registered for event")
    feedbacks.append(Feedback(student_id=student_id, event_id=event_id, rating=rating))
    return {"status": "feedback_received", "event_id": event_id, "student_id": student_id, "rating": rating}

# -----------------------------
# Reports
# -----------------------------
@app.get("/reports/event-popularity")
def event_popularity():
    report = []
    for e in events:
        count = sum(1 for r in registrations if r.event_id == e.id)
        report.append({"event_id": e.id, "title": e.title, "registrations": count})
    report.sort(key=lambda x: x["registrations"], reverse=True)
    return report

@app.get("/reports/student-participation")
def student_participation():
    report = []
    for s in students:
        attended = sum(1 for r in registrations if r.student_id == s.id and r.checked_in)
        report.append({"student_id": s.id, "name": s.name, "events_attended": attended})
    return report

@app.get("/reports/top-students")
def top_students():
    report = []
    for s in students:
        attended = sum(1 for r in registrations if r.student_id == s.id and r.checked_in)
        report.append({"student_id": s.id, "name": s.name, "events_attended": attended})
    report.sort(key=lambda x: x["events_attended"], reverse=True)
    return report[:3]  # top 3 students